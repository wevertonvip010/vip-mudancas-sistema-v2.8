# 🏢 Sistema VIP Mudanças v2.6 - Versão Final

## 📋 Sobre o Sistema

Sistema completo de gerenciamento para empresa de mudanças, desenvolvido especificamente para a VIP Mudanças. Inclui todos os módulos necessários para gestão operacional, comercial e financeira.

## 🚀 Funcionalidades Implementadas

### 🔐 **Autenticação**
- Login seguro com persistência
- Credenciais: `admin@vip.com.br` / `123456`
- Redirecionamento automático para dashboard

### 🏠 **Dashboard**
- Métricas em tempo real
- Cards dinâmicos (mudanças, boxes, visitas, receita)
- Atividades recentes
- Status do sistema
- Acesso rápido aos módulos

### 👥 **Clientes**
- Cadastro completo (nome, CPF/CNPJ, contatos, endereço)
- Listagem com filtros e busca
- Histórico de contratos e mudanças
- 10 clientes mockados

### 📅 **Visitas**
- Agendamento de visitas técnicas
- Integração mock com Google Agenda
- Responsáveis técnicos configurados
- Status: agendada, realizada, cancelada
- Filtros por data e status

### 💰 **Orçamentos**
- Criação com múltiplos modelos (PDF/Word)
- Cálculo automático de totais
- Visualização prévia profissional
- Envio por email e WhatsApp (mock)
- Numeração automática (ORC-001-2024)
- Status: pendente, enviado, aprovado, rejeitado

### 📄 **Contratos**
- Geração automática a partir de orçamentos aprovados
- Numeração sequencial (CONT-001-2025)
- Campos preenchíveis completos
- Cláusulas contratuais editáveis
- Download em PDF (mock)
- Status: ativo, executado, cancelado, vencido

### 🚛 **Ordens de Serviço**
- Geração automática a partir de contratos
- Numeração sequencial (OS-001-2025)
- Gestão completa da equipe operacional
- Controle de veículos e recursos
- Lista detalhada de itens
- Checklist de preparação
- Status operacionais completos

### 🏢 **Self Storage (56 Boxes)**
- Cadastro completo dos 56 boxes
- Dimensões (altura, largura, profundidade)
- Status: livre, ocupado, manutenção
- Dados do cliente e data de entrada
- Filtros por status e busca
- Modais para visualização e edição
- Exportação para PDF

### 📦 **Estoque**
- Planilha embutida com botões [+] e [-]
- Itens padrão: caixas, plástico bolha, papelão, fita, formulários
- Controle de movimentações (entrada/saída)
- Alertas de estoque baixo
- Histórico de movimentações
- Exportação para CSV

### 💰 **Financeiro Avançado**
- **Separação por centros de custo:**
  - Self Storage (receitas por box, despesas fixas)
  - Mudanças (receitas por serviço, custos operacionais)
- Gráficos comparativos entre segmentos
- Total consolidado mensal
- Controle de entradas e saídas
- Categorização de despesas

### 🛒 **Vendas (CRM)**
- Pipeline visual com 5 estágios
- Kanban: Novo Lead → Proposta → Negociação → Fechado/Perdido
- Métricas em tempo real (conversão, faturamento)
- Gestão completa de leads
- Filtros por vendedor e status
- Histórico e probabilidades

### 📊 **Gráficos Interativos**
- Faturamento mensal (Self Storage vs Mudanças)
- Avaliações de clientes com linha temporal
- Ocupação de boxes em pizza interativa
- Performance de vendedores
- Consumo de estoque em área empilhada
- Evolução do saldo com entradas/saídas
- Insights automáticos e recomendações

### 📣 **Marketing**
- Painel de campanhas completo
- Tipos: Meta Ads, Google Ads, Influencer, Offline
- ROI estimado e real
- Status: ativa, pausada, finalizada
- Upload de criativos (mock)
- Métricas de performance
- Gráficos de resultados

### ⚙️ **Configurações**
- **Gestão de Usuários:**
  - Cadastro de novos usuários
  - Permissões por cargo (Admin, Comercial, Operacional, Financeiro)
  - Ativação/desativação
  - Edição de dados e permissões
- **Configurações da Empresa:**
  - Dados completos editáveis
  - Informações de contato
- **IA Mirante:**
  - Campo para Token OpenAI
  - Teste de conectividade
  - Status visual do token

### 🤖 **IA Mirante (Assistente Virtual)**
- Botão flutuante sempre visível
- Interface conversacional completa
- Respostas inteligentes sobre o sistema
- Sugestões automáticas de perguntas
- Funcionalidades:
  - Copiar mensagens
  - Avaliar respostas (👍/👎)
  - Limpar conversa
  - Minimizar/maximizar
  - Status online
- Preparado para integração com OpenAI

### 📋 **Módulos Adicionais**
- **Programa de Pontos:** Sistema gamificado para funcionários
- **Calendário:** Integração com eventos e compromissos
- **Leads LinkedIn:** Gestão de leads da rede social
- **Licitações Públicas:** Monitoramento de editais

## 🔄 **Integrações Entre Módulos**

O sistema possui fluxo completo integrado:
1. **Visita** → **Orçamento** → **Contrato** → **Ordem de Serviço**
2. Dados fluem automaticamente entre módulos
3. Numeração automática e sequencial
4. Status acompanhados em tempo real
5. Alimentação automática do financeiro
6. Atualização das métricas do dashboard

## 🛠️ **Tecnologias Utilizadas**

- **Frontend:** React 18 + Vite
- **Styling:** Tailwind CSS
- **Icons:** Lucide React
- **Charts:** Recharts
- **Routing:** React Router DOM
- **State:** React Hooks (useState, useEffect, useContext)

## 📦 **Instalação e Execução**

### Pré-requisitos
- Node.js 18+ 
- npm ou yarn

### Passos para execução local:

```bash
# 1. Extrair o projeto
unzip vip-mudancas-sistema-v2.6-final.zip
cd vip-mudancas

# 2. Instalar dependências
cd frontend
npm install

# 3. Executar em desenvolvimento
npm run dev

# 4. Acessar o sistema
# Abrir http://localhost:5173
```

### Para build de produção:

```bash
# Build para produção
npm run build

# Os arquivos estarão em dist/
```

## 🔐 **Credenciais de Acesso**

- **Email:** admin@vip.com.br
- **Senha:** 123456

## 📁 **Estrutura do Projeto**

```
frontend/
├── src/
│   ├── components/          # Componentes reutilizáveis
│   │   ├── Layout.jsx       # Layout principal
│   │   ├── Sidebar.jsx      # Barra lateral
│   │   ├── Header.jsx       # Cabeçalho
│   │   ├── ProtectedRoute.jsx # Rotas protegidas
│   │   └── IAMirante.jsx    # Assistente IA
│   ├── pages/               # Páginas do sistema
│   │   ├── Login.jsx        # Página de login
│   │   ├── Dashboard.jsx    # Dashboard principal
│   │   ├── Clientes.jsx     # Gestão de clientes
│   │   ├── Visitas.jsx      # Agendamento de visitas
│   │   ├── Orcamentos.jsx   # Criação de orçamentos
│   │   ├── Contratos.jsx    # Gestão de contratos
│   │   ├── OrdensServico.jsx # Ordens de serviço
│   │   ├── SelfStorage.jsx  # Guarda-móveis
│   │   ├── Estoque.jsx      # Controle de estoque
│   │   ├── Financeiro.jsx   # Gestão financeira
│   │   ├── Vendas.jsx       # CRM de vendas
│   │   ├── Graficos.jsx     # Gráficos e relatórios
│   │   ├── Marketing.jsx    # Campanhas de marketing
│   │   └── Configuracoes.jsx # Configurações
│   ├── hooks/               # Hooks customizados
│   │   └── useAuth.jsx      # Hook de autenticação
│   ├── lib/                 # Utilitários
│   │   └── api.js           # Simulação de API
│   ├── data/                # Dados mockados
│   │   └── mockData.js      # Dados de exemplo
│   ├── App.jsx              # Componente principal
│   └── main.jsx             # Ponto de entrada
├── public/                  # Arquivos públicos
├── package.json             # Dependências
└── vite.config.js           # Configuração do Vite
```

## 🎯 **Status de Desenvolvimento**

### ✅ **100% Implementado:**
- Autenticação e autorização
- Dashboard com métricas
- Todos os módulos principais
- Integrações entre módulos
- IA Mirante funcional
- Interface responsiva
- Dados mockados completos

### 🔄 **Preparado para Integração:**
- Campo para Token OpenAI (Configurações)
- Estrutura para APIs reais
- Webhooks preparados
- Sistema de notificações

### 📋 **Próximos Passos (Equipe Interna):**
1. Conectar APIs reais (Google, WhatsApp, OpenAI)
2. Configurar Token OpenAI nas Configurações
3. Implementar envios reais de email/WhatsApp
4. Conectar com banco de dados real
5. Deploy em produção

## 🌐 **Deploy**

O sistema está preparado para deploy em:
- **Vercel** (recomendado para frontend)
- **Netlify**
- **Google Cloud** (conforme preferência)
- **Servidor próprio**

## 📞 **Suporte**

Sistema desenvolvido especificamente para VIP Mudanças.
Para suporte técnico, consulte a documentação interna ou equipe de TI.

---

**© 2024 VIP Mudanças - Sistema Unificado v2.6**
*Desenvolvido com ❤️ para otimizar sua operação*

